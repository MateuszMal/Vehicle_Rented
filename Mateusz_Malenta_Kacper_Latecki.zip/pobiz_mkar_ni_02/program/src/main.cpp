#include <iostream>
#include <model/Address.h>
#include <model/Client.h>
#include <model/Rent.h>

using namespace std;

int main()
{
    cout << "Hello Wypozyczalnia" << endl;

    return 0;
}
